<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Commerce</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,400i,600,700|Raleway:300,400,400i,500,500i,700,800,900" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: eBusiness
  * Updated: Sep 18 2023 with Bootstrap v5.3.2
  * Template URL: https://bootstrapmade.com/ebusiness-bootstrap-corporate-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <?php include "header.php"; ?>
  <!-- End Header -->

  <main id="main">

    <!-- ======= Blog Header ======= -->
    <div class="header-bg page-area">
      <div class="container position-relative">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="slider-content text-center">
              <div class="header-bottom">
                <div class="layer2">
                  <h1 class="title2">Commerce</h1>
                </div>
                <div class="layer3">
                  <h3 class="title3"></h3>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div><!-- End Blog Header -->

    <!-- ======= Blog Page ======= -->
    <div class="blog-page area-padding">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 col-md-4">
            <div class="page-head-blog">
              <div class="single-blog-page">
                <!-- search option start -->
                <form action="#">
                  <div class="search-option">
                    <input type="text" placeholder="Search...">
                    <button class="button" type="submit">
                      <i class="bi bi-search"></i>
                    </button>
                  </div>
                </form>
                <!-- search option end -->
              </div>
              <div class="single-blog-page">
                <!-- recent start -->
                <?php include "sidebar.php"; ?>
          <!-- Start single blog -->
          <div class="col-md-8 col-sm-8 col-xs-12">
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <!-- single-blog start -->
                <article class="blog-post-wrapper">
                  <div class="post-thumbnail">
                    <img src="assets/img/course-page/commerce/1.jpg" alt="" />
                  </div>
                  <div class="post-information">
                    <h2>To become a dream destination for those aspiring to pursue their interests in the discipline of Commerce education</h2>
                    <div class="entry-meta">
                      <span class="author-meta"><i class="bi bi-person"></i> <a href="#">HOD</a></span>
                      <span><i class="bi bi-clock"></i> 2009</span>
                      <span class="tag-meta">
                        <i class="bi bi-folder"></i>
                        <a href="#">vision</a>,
                        <a href="#">mission</a>
                      </span>
                      
                      
                    </div>
                    <div class="entry-content">
                      <p>To educate the students to empower, explore new opportunities and make them to excel in the field of Commerce.To enable the students to take up employment in various organizations and self-employment.
To enable the students to acquire knowledge required to establish and run business of their own.</p>
                      <blockquote>
                        <p>Providing teaching excellence and support services and enabling students to have opportunity to succeed.
Incorporating innovative and creative methods and processes in student's curricular activities.
Ensuring academic freedom and freedom of speech during student's activities.</p>
                      </blockquote>
                      <p>The Department of Commerce with Computer Applications is one of the pioneering departments of the institution which came into existence in the year 2000. The Department offers B.Com (CA)., M.Com (CA)., and research programmes. The Department focuses knowledge enhancement, values and ethics, innovative thinking abilities , developing leadership skills, providing mentorship opportunities, entrepreneurial skills and various skills for employment matching the requirements of corporate world by maintaining high quality of education and research. The area of research includes marketing, finance, and human resources. The study of commerce provides a springboard for work opportunities in the range of financial services, banking, industry, law and government services. At present, the commerce with computer applications is potentially the most preferred academic choice among the students.</p>
    
                      <b>scope of department</b>
    
                      
                      <p>Accounting and Commerce is a field for students who have an interest in financial information/transactions, trading of economic value, etc. Students often consider taking up Commerce courses after completing Class 12. Students who are looking forward to pursuing a career in Commerce have a wide range of choices before them. Candidates can pursue a course in commerce stream at the undergraduate (UG), postgraduate (PG), and Diploma levels as well as at the doctoral level.

UG-level Commerce courses offered to aspirants include BCom, BBA, CA, CS, BBA LLB, BBM, BSc, etc. At the PG level, popular Commerce programmes are MCom, MBA, MPhil, MSc, etc. Generally speaking, UG courses in Commerce stream are of three years duration whereas PG programmes are of two years' duration. The fees of these courses can range between INR 2 LPA to 6 LPA.

Among the Commerce courses, students can consider choosing specialisations such as Accounting and Finance, Banking and Finance, Accounting and Taxation, Actuarial Science, Business Administration, Applied Economics, E-Commerce, Financial Accounting, Banking and Insurance, Human Resources, Entrepreneurship, Accounting and Auditing, etc. As the commerce scope is widening day-by-day, the graduates can find employment in various sectors such as Clerk, Cashier, Bank Accountant, Sales Manager, Security Analyst, etc.
</p>
                    </div>
                  </div>
                </article>
                <div class="clear"></div>
                <div class="">
                    </div>
                  </div>
                  <div class="">
                    
                  </div>
                </div>
                <!-- single-blog end -->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div><!-- End Blog Page -->


     <!-- ======= Blog Section ======= -->
     <?php include "courses.php"; ?>
    <!-- End Blog Section -->
   

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php include "footer.php"; ?>

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <?php include "scripts.php"; ?>
</body>

</html>
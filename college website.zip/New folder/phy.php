<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>physics</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,400i,600,700|Raleway:300,400,400i,500,500i,700,800,900" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: eBusiness
  * Updated: Sep 18 2023 with Bootstrap v5.3.2
  * Template URL: https://bootstrapmade.com/ebusiness-bootstrap-corporate-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <?php include "header.php"; ?>
  <!-- End Header -->

  <main id="main">

    <!-- ======= Blog Header ======= -->
    <div class="header-bg page-area">
      <div class="container position-relative">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="slider-content text-center">
              <div class="header-bottom">
                <div class="layer2">
                  <h1 class="title2">Physics</h1>
                </div>
                <div class="layer3">
                  <h3 class="title3"></h3>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div><!-- End Blog Header -->

    <!-- ======= Blog Page ======= -->
    <div class="blog-page area-padding">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 col-md-4">
            <div class="page-head-blog">
              <div class="single-blog-page">

                <!-- search option start -->
                <form action="#">
                  <div class="search-option">
                    <input type="text" placeholder="Search...">
                    <button class="button" type="submit">
                      <i class="bi bi-search"></i>
                    </button>
                  </div>
                </form>
                <!-- search option end -->
              </div>
              <div class="single-blog-page">
                <!-- recent start -->
                <?php include "sidebar.php"; ?>
          <!-- Start single blog -->
          <div class="col-md-8 col-sm-8 col-xs-12">
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <!-- single-blog start -->
                <article class="blog-post-wrapper">
                  <div class="post-thumbnail">
                    <img src="assets/img/course-page/phy/1.jpg" alt="" />
                  </div>
                  <div class="post-information">
                    <h2>aims to provide Quality Education in Science for the fulfillment of individual and social needs and to take up responsibilities especially to uplift the weaker sections of the society.</h2>
                    <div class="entry-meta">
                      <span class="author-meta"><i class="bi bi-person"></i> <a href="#">HOD</a></span>
                      <span><i class="bi bi-clock"></i> 2009</span>
                      <span class="tag-meta">
                        <i class="bi bi-folder"></i>
                        <a href="#">vision</a>,
                        <a href="#">mission</a>
                      </span>
                      
                      
                    </div>
                    <div class="entry-content">
                      <p>The Department of Physics aims to provide Quality Education in Science for the fulfillment of individual and social needs and to take up responsibilities especially to uplift the weaker sections of the society.</p>
                      <blockquote>
                        <p>Providing teaching excellence and support services and enabling students to have opportunity to succeed.</p>
                      </blockquote>
                      <p>
                        The Department has produced Rank Holders and Gold Medalist in the University Examinations and also produced the Best Out Going Student, Priyanka Chand Gothia (2010-11) at the U.G. Level.
                        The Department of Physics began functioning from 1996 with commencement of Graduation (Physics) course At present the department offers Physics as a subject for B.Sc. (Maths group). The Department is well equipped with necessary facilities and resources for teaching , higher learning .
                        The sincere and dedicated academic and non-academic staff members have been the pillars of the department, who have played key roles in the overall development of the department. They continue guiding students in achieving academic excellence and improvement of overall personality. Over the years, the students of Physics Department have been offered high quality education, with special personal care being extended to the students hailing from socially and economically weaker sections of the society.
                        According to physics the world consists of matter and energy. The study of physics encompasses the areas: force & motion, light, sound, electricity magnetism ,electronics ,electrical and structure of matter.
                        basic science especially Physics plays an important role in building the foundation for all engineering fields. Further it is very essential for all the Science students to have the knowledge of fundamentals of different aspects of physics, so as to apply them in various fields e.g. semiconductor physics in microelectronics, optics in optical fibre communication, optical amplification and multiplication, magnetic properties in computer memories, lasers for various industrial applications, modern physics in nuclear power generation and Soil Physics in Soil analysis
                      </p>
                        <b>Scope of Department</b>
                      <p>
                        A direct course to secure scientist positions in DRDO, DAE, BARC, ISRO
                        To achieve scientist career openings in Indian Meteorological departments, space organizations and energy sectors
                        Can avail career positions in Solar Industries, Battery Industries, Communication Technologies, Healthcare Instrumentation Laboratories, Nuclear Power Plants and Geo-Spatial Technologies
                      </p>
                    </div>
                  </div>
                </article>
                
                <div class="clear"></div>
                <div class="">
                    </div>
                  </div>
                  <div class="">

                  </div>
                </div>
                <!-- single-blog end -->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div><!-- End Blog Page -->


     <!-- ======= Blog Section ======= -->
     <?php include "courses.php"; ?>
    <!-- End Blog Section -->
   

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php include "footer.php"; ?>

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <?php include "scripts.php"; ?>
</body>

</html>
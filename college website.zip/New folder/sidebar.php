
                <!-- recent end -->
              </div>
              <div class="single-blog-page">
                <div class="left-blog">
                  <h4>DEPARTMENTS</h4>
                  <ul>
                    <li>
                      <a href="it.php">Information Technology</a>
                    </li>
                    <li>
                      <a href="cs.php">Computer Science</a>
                    </li>
                    <li>
                      <a href="phy.php">Physics</a>
                    </li>
                    <li>
                      <a href="bio.php">Bio technology</a>
                    </li>
                    <li>
                      <a href="commerce.php">commerce</a>
                    </li>
                  </ul>
                </div>
              </div>
              <!--<div class="single-blog-page">
                <div class="left-blog">
                  <h4>Prominent Alumni</h4>
                  <ul>
                    <li>
                      <a href="#"><b>Balachandar</b> whatsapp signal messenger</a>
                    </li>
                    <li>
                      <a href="#"><b>Praveen</b> Researcher microsoft</a>
                    </li>
                    <li>
                      <a href="#"><b>Dhinakaran</b> Associate Tech lead</a>
                    </li>
                    <li>
                      <a href="#"><b>Gokul kumar</b> SEE dubai </a>
                    </li>
                    <li>
                      <a href="#"><b>Siddharthan</b> World Bank Group Chennai</a>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="single-blog-page">
                <div class="left-tags blog-tags">
                  <div class="popular-tag left-side-tags left-blog">
                    <h4>Bulletin</h4>
                    <ul>
                      <li>
                        <a href="#">Dec-Feb</a>
                      </li>
                      <li>
                        <a href="#">July-sep</a>
                      </li>
                      <li>
                        <a href="#">Dec-Feb</a>
                      </li>
                      <li>
                        <a href="#">July-sep</a>
                      </li>
                      <li>
                        <a href="#">Dec-feb</a>
                      </li>
                      <li>
                        <a href="#">July-sep</a>
                      </li>
                      <li>
                        <a href="#">Dec-Feb</a>
                      </li>
                      <li>
                        <a href="#">July-sep</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>-->
            </div>
          </div>
          <!-- End left sidebar -->
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Information technology</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,400i,600,700|Raleway:300,400,400i,500,500i,700,800,900" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: eBusiness
  * Updated: Sep 18 2023 with Bootstrap v5.3.2
  * Template URL: https://bootstrapmade.com/ebusiness-bootstrap-corporate-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <?php include "header.php"; ?>
  <!-- End Header -->

  <main id="main">

    <!-- ======= Blog Header ======= -->
    <div class="header-bg page-area">
      <div class="container position-relative">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="slider-content text-center">
              <div class="header-bottom">
                <div class="layer2">
                  <h1 class="title2">Information technology</h1>
                </div>
                <div class="layer3">
                  <h3 class="title3"></h3>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div><!-- End Blog Header -->

    <!-- ======= Blog Page ======= -->
    <div class="blog-page area-padding">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 col-md-4">
            <div class="page-head-blog">
              <div class="single-blog-page">
                <!-- search option start -->
                <form action="#">
                  <div class="search-option">
                    <input type="text" placeholder="Search...">
                    <button class="button" type="submit">
                      <i class="bi bi-search"></i>
                    </button>
                  </div>
                </form>
                <!-- search option end -->
              </div>
              <div class="single-blog-page">
                <!-- recent start -->
                <?php include "sidebar.php"; ?>
          <!-- Start single blog -->
          <div class="col-md-8 col-sm-8 col-xs-12">
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <!-- single-blog start -->
                <article class="blog-post-wrapper">
                  <div class="post-thumbnail">
                    <img src="assets/img/course-page/IT/4.jpg" alt="" />
                  </div>
                  <div class="post-information">
                    <h2>The aim of imparting quality education in the field of Information Technology.</h2>
                    <div class="entry-meta">
                      <span class="author-meta"><i class="bi bi-person"></i> <a href="#">HOD</a></span>
                      <span><i class="bi bi-clock"></i> 2009</span>
                      <span class="tag-meta">
                        <i class="bi bi-folder"></i>
                        <a href="#">vision</a>,
                        <a href="#">mission</a>
                      </span>
                      
                      
                    </div>
                    <div class="entry-content">
                      <p>The department of Computer Technology and Information Technology was established in the year 2008 and later it was bifurcated from the department of PG computer Science into a separate one in the year 2009. The department is functioning with the aim of imparting quality education in the field of Information Technology.</p>
                      <blockquote>
                        <p>To impart knowledge and skills to the students through training and research activities to make them as competent and renowned IT Professionals.</p>
                      </blockquote>
                      <p>The Department has produced Rank Holders and Gold Medalist in the University Examinations and also produced the Best Out Going Student, Priyanka Chand Gothia (2010-11) at the U.G. Level.
A team of well qualified, experienced faculty members organize various innovative programmes.
Well equipped and spacious class rooms providing a conducive environment for learning.
State - of- Art Computer Lab and Internet facilities.
Large collection of books at the Department Library.
Tutor guidance / counselling is provided to each student.
The CT IT Student Council is functioning to improve the various skills of the students.
Students are encouraged to present their papers in seminar/conferences and also encouraged to participate in co-curricular and extra-curricular activities.
The Department offers Value Added Courses.
Regular industrial visits are arranged.
Assists students to get placed in corporate companies.
The Department organizes an alumni meet 'REUNION' at regular intervals.</p>
<b>Scope of Department</b>
<p>
Information Technology is one of the most promising career fields today. At the forefront of development in the IT Engineering field, IT is witnessing advancements in leaps and bounds every year. The field of Information Technology has been the catalyst to people transition into a simpler, smoother functioning of life. Technology has introduced enormous changes in the way we do things, the way we function in our daily lives. 
Professionals working in the IT Engineering sector are trained to be highly competent and are constantly motivated toward innovation. Some of the innovations made by them in recent years are social media, digital marketing, mobile and web applications, Internet banking, and countless other ideas which have transformed our lives completely. It is this innovation which is still underway, with immeasurable scope for bringing about more change. Both in India and abroad, there is tremendous scope for professionals of the Information Technology sector to contribute to human beings development. 
</p>
                    </div>
                  </div>
                </article>
                <div class="clear"></div>
                <div class="">
                    </div>
                  </div>
                  <div class="">
                    
                  </div>
                </div>
                <!-- single-blog end -->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div><!-- End Blog Page -->


     <!-- ======= Blog Section ======= -->
     <?php include "courses.php"; ?>
    <!-- End Blog Section -->
   

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php include "footer.php"; ?>

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <?php include "scripts.php"; ?>
</body>

</html>
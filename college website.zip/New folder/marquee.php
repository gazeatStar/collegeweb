<div id="marquee" class="marquee">
<div class="marquee-container">
  <h1>Grand celebration for 75 years of KASC</h1>
  <h3>chief guest - Dr.ramapathy</h3>
  
</div>

<style>
  .marquee-container {
      width: 100%;
      overflow: hidden;
      white-space: nowrap;
      animation: marquee 10s linear infinite;
  }
  h1 {
  text-align: center;
  font-style: italic;
  font-family: Arial, Helvetica, sans-serif;
  font-size: 35px;
  color: white;
  text-shadow: 1px 1px 2px lightblue, 0 0 25px blue, 0 0 5px darkblue;
}
h3{
  color:rgb(0, 153, 204);
  text-align: center;
  font-size: 25px;
  font-family: monospace;
}
  @keyframes marquee {
      0% { transform: translateX(100%); }
      100% { transform: translateX(-100%); }
  }
</style>
</div>
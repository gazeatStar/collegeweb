<!-- box start -->
<<a href="#" class="box">
                  <p class="box-text"> DR ruba </p>
                
                <style>
                     .box {
                        width: 150px;
                         height: 100px;
                         background-color: #ff6666;
                         border: 1px solid #ccc;
                         border-radius: 10px;
                         padding: 0px;
                         text-align: center;
                         margin: 5px auto;
                         box-shadow: 0 4px 8px rgba(128, 0, 255);
                         }
                       .box-text {
                         font-family: 'Arial', sans-serif;
                          color: #3d0099;
                          font-size: 8px;
                          font-weight: bold;
                          }
                        a:hover {
                         background-color: #ddd; 
                         }
                </style>
              </a>
                <!-- box end -->

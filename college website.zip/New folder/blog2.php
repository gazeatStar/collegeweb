<!-- ======= Blog Section ======= -->
<div id="blog" class="blog-area">
    <div class="blog-inner area-padding">
      <div class="blog-overly"></div>
      <div class="container ">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="section-headline text-center">
              <h2>Courses</h2>
            </div>
          </div>
        </div>
        <div class="row">
          <!-- Start Left Blog -->
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="single-blog">
              <div class="single-blog-img">
                <a href="blog.html">
                  <img src="assets/img/courses/it.png" alt="">
                </a>
              </div>
              <div class="blog-meta">
                <span class="comments-type">
                  <i class="fa fa-comment-o"></i>
                </span>
              </div>
              <div class="blog-text">
                <h4>
                  <a href="blog.html">Information Technology</a>
              </div>
              <span>
                <a href="info.html" class="ready-btn">Read more</a>
              </span>
            </div>
            <!-- Start single blog -->
          </div>
          <!-- End Left Blog-->
          <!-- Start Left Blog -->
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="single-blog">
              <div class="single-blog-img">
                <a href="blog.html">
                  <img src="assets/img/courses/cs.jpeg" alt="">
                </a>
              </div>
              <div class="blog-meta">
                <span class="comments-type">
                  <i class="fa fa-comment-o"></i>
                </span>
              </div>
              <div class="blog-text">
                <h4>
                  <a href="blog.html">Computer Science</a>
                </h4>
              </div>
              <span>
                <a href="blog.html" class="ready-btn">Read more</a>
              </span>
            </div>
            <!-- Start single blog -->
          </div>
          <!-- End Left Blog-->
          <!-- Start Right Blog-->
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="single-blog">
              <div class="single-blog-img">
                <a href="blog.html">
                  <img src="assets/img/courses/bio.jpg" alt="">
                </a>
              </div>
              <div class="blog-meta">
                <span class="comments-type">
                  <i class="fa fa-comment-o"></i>
                </span>
              </div>
              <div class="blog-text">
                <h4>
                  <a href="blog.html">Bio-Chemistry</a>
                </h4>
              </div>
              <span>
                <a href="blog.html" class="ready-btn">Read more</a>
              </span>
            </div>
          </div>
          <!-- End Right Blog-->
        </div>
      </div>
    </div>
  </div><!-- End Blog Section -->
  <!-- ======= Blog Section ======= -->
  <div id="blog" class="blog-area">
    <div class="blog-inner area-padding">
      <div class="blog-overly"></div>
      <div class="container ">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="section-headline text-center">
            </div>
          </div>
        </div>
        <div class="row">
          <!-- Start Left Blog -->
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="single-blog">
              <div class="single-blog-img">
                <a href="blog.html">
                  <img src="assets/img/courses/maths.jpeg" alt="">
                </a>
              </div>
              <div class="blog-meta">
                <span class="comments-type">
                  <i class="fa fa-comment-o"></i>
                </span>
              </div>
              <div class="blog-text">
                <h4>
                  <a href="blog.html">Physics</a>
                </h4>
               
              </div>
              <span>
                <a href="blog.html" class="ready-btn">Read more</a>
              </span>
            </div>
            <!-- Start single blog -->
          </div>
          <!-- End Left Blog-->
          <!-- Start Left Blog -->
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="single-blog">
              <div class="single-blog-img">
                <a href="blog.html">
                  <img src="assets/img/courses/bba1.jpg" alt="">
                </a>
              </div>
              <div class="blog-meta">
                <span class="comments-type">
                  <i class="fa fa-comment-o"></i>
                  
                </span>
                
              </div>
              <div class="blog-text">
                <h4>
                  <a href="blog.html">Business Administration</a>
                </h4>
                
              </div>
              <span>
                <a href="blog.html" class="ready-btn">Read more</a>
              </span>
            </div>
            <!-- Start single blog -->
          </div>
          <!-- End Left Blog-->
          <!-- Start Right Blog-->
          <div class="col-md-4 col-sm-4 col-xs-12">
            <div class="single-blog">
              <div class="single-blog-img">
                <a href="blog.html">
                  <img src="assets/img/courses/phy.jpg" alt="">
                </a>
              </div>
              <div class="blog-meta">
                <span class="comments-type">
                  <i class="fa fa-comment-o"></i>
                </span>
              </div>
              <div class="blog-text">
                <h4>
                  <a href="blog.html">Physics</a>
                </h4>
              </div>
              <span>
                <a href="blog.html" class="ready-btn">Read more</a>
              </span>
            </div>
          </div>
          <!-- End Right Blog-->
        </div>
      </div>
    </div>
  </div><!-- End Blog Section -->
</div>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Bio technology</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,400i,600,700|Raleway:300,400,400i,500,500i,700,800,900" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: eBusiness
  * Updated: Sep 18 2023 with Bootstrap v5.3.2
  * Template URL: https://bootstrapmade.com/ebusiness-bootstrap-corporate-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <?php include "header.php"; ?>
  <!-- End Header -->

  <main id="main">

    <!-- ======= Blog Header ======= -->
    <div class="header-bg page-area">
      <div class="container position-relative">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="slider-content text-center">
              <div class="header-bottom">
                <div class="layer2">
                  <h1 class="title2">Bio technology</h1>
                </div>
                <div class="layer3">
                  <h3 class="title3"></h3>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div><!-- End Blog Header -->

    <!-- ======= Blog Page ======= -->
    <div class="blog-page area-padding">
      <div class="container">
        <div class="row">
          <div class="col-lg-4 col-md-4">
            <div class="page-head-blog">
              <div class="single-blog-page">
                <!-- search option start -->
                <form action="#">
                  <div class="search-option">
                    <input type="text" placeholder="Search...">
                    <button class="button" type="submit">
                      <i class="bi bi-search"></i>
                    </button>
                  </div>
                </form>
                <!-- search option end -->
              </div>
              <div class="single-blog-page">
                <!-- recent start -->
                <?php include "sidebar.php"; ?>
          <!-- Start single blog -->
          <div class="col-md-8 col-sm-8 col-xs-12">
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <!-- single-blog start -->
                <article class="blog-post-wrapper">
                  <div class="post-thumbnail">
                    <img src="assets/img/course-page/bio/1.jpg" alt="" />
                  </div>
                  <div class="post-information">
                    <h2>To bring students to the enquiry mode so as to develop qualities of questioning, reflecting and understanding instead of accepting, reading and memorizing.</h2>
                    <div class="entry-meta">
                      <span class="author-meta"><i class="bi bi-person"></i> <a href="#">HOD</a></span>
                      <span><i class="bi bi-clock"></i> 2009</span>
                      <span class="tag-meta">
                        <i class="bi bi-folder"></i>
                        <a href="#">vision</a>,
                        <a href="#">mission</a>
                      </span>
                      
                      
                    </div>
                    <div class="entry-content">
                      <p>The Department of Physics aims to provide Quality Education in Science for the fulfillment of individual and social needs and to take up responsibilities especially to uplift the weaker sections of the society.</p>
                      <blockquote>
                        <p>Providing teaching excellence and support services and enabling students to have opportunity to succeed.
Incorporating innovative and creative methods and processes in student's curricular activities.
Ensuring academic freedom and freedom of speech during student's activities.</p>
                      </blockquote>
                      <p>The Department has independent laboratory fully equipped with instruments
It caters the student's need to make them familiar with basic techniques.
Our laboratory aims to offer necessary technical inputs and to provide the students with basic knowledge and skills in application-oriented experiments in biosciences.BSc Biotechnology is a three-year undergraduate course that delves into various concepts of Biotechnology, through the curriculum and subjects which are taught during the programme. BSc Biotechnology can be defined as the technology that utilises biological systems, living organisms or parts of these to develop or create different products.
BSc Biotechnology is offered across various government and private colleges and universities across India. BSc Biotechnology syllabus and curriculum are more or less similar or universal across institutes offering the programme. Students who have studied Biology at the senior secondary level and want to pursue a higher level of the subject alongside focusing on the technological aspect should go for BSc Biotechnology.
This page of Shiksha brings you an in-depth understanding of what a BSc Biotechnology programme has in store for candidates in terms of syllabus, curriculum, scope, career, and much more. Candidates can read further to know more about the BSc Biotechnology course details.</p>
<b>Scope of Department</b>
<p>
The current boom in the arena of research and development led by Biotechnology is nothing short of a revolution across different fields of Medical Science. Be it the growth in Biochemical Engineering, making bioprinting more accessible, or generation of energy through bio-sources, biotechnologists are at the forefront of constant evolution and innovation. While the past decade has observed some staggering and monumental rates of growth when it comes to the scope of biotechnology and its allied sectors, in the future, it may become one of the prominent industries to watch out for in the next one.</p>
                    </div>
                  </div>
                </article>
                <div class="clear"></div>
                <div class="">
                    </div>
                  </div>
                  <div class="">
                    
                  </div>
                </div>
                <!-- single-blog end -->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div><!-- End Blog Page -->


     <!-- ======= Blog Section ======= -->
     <?php include "courses.php"; ?>
    <!-- End Blog Section -->
   

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php include "footer.php"; ?>

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <?php include "scripts.php"; ?>
</body>

</html>
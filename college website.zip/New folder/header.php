<header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex justify-content-between">
      
      <div class="logo">
        <h1><a href="index.php">Kongu</a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="index.php">Home</a></li>
          <li><a class="nav-link scrollto" href="index.php#about">About</a></li>
          <li class="dropdown"><a href="#"><span>Courses</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="it.php">Information Technology</a></li>
              <li><a href="phy.php">physics</a></li>
              <li><a href="cs.php">computer science</a></li>
              <li><a href="bio.php">bio technology</a></li>

              <li class="dropdown"><a href="#"><span>Deep Drop Down</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                <li><a href="commerce.php">commerce</a></li>
                  <li><a href="phy.php">physics</a></li>
                  <li><a href="cs.php">computer science</a></li>
                </ul>
              </li>
              
            </ul>
          </li>
          
          <li><a class="nav-link scrollto" href="index.php#portfolio">Gallery</a></li>
          <li><a class="nav-link scrollto" href="index.php#team">Team</a></li>
         

          <li><a class="nav-link scrollto" href="index.php#contact">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->
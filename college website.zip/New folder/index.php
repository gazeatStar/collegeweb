<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>KASC</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

 <?php include "links.php"; ?>

  <!-- =======================================================
  * Template Name: eBusiness
  * Updated: Sep 18 2023 with Bootstrap v5.3.2
  * Template URL: https://bootstrapmade.com/ebusiness-bootstrap-corporate-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <?php include "header.php"; ?>

  <!-- ======= hero Section ======= -->
  <?php include "banner.php"; ?>
 <!-- End Hero Section -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <?php include "about.php"; ?>
   <!-- End About Section -->

  

    <!-- ======= Services Section ======= -->
    <?php include "service.php"; ?>
    <!-- End Services Section -->

    <!-- ======= Team Section ======= -->
    <?php include "team.php"; ?>
    <!-- End Team Section -->

    <!-- ======= Rviews Section ======= -->
    <?php include "review.php"; ?>
    <!-- End Rviews Section -->

    <!-- ======= Portfolio Section ======= -->
    <?php include "gallery.php"; ?>
  <!-- End Portfolio Section -->

   <!-- ======= Testimonials Section ======= -->
   <?php include "testimonials.php"; ?>
    <!-- End Testimonials Section -->

    <!-- ======= Blog Section ======= -->
    <?php include "blog.php"; ?>
    <!-- End Blog Section -->
    
<!--marquee-->
<?php include "marquee.php"; ?>
<!--marquee end-->


    <!-- ======= Video ======= -->
    <?php include "video.php"; ?>
<!-- ===== End of Video ======= -->

<!-- ======= Blog Section ======= -->
<?php include "blog.php"; ?>
<!-- End Blog Section -->



<?php include "courses.php"; ?>




    <!-- ======= Suscribe Section ======= -->
    <?php include "subscribe.php"; ?>
    <!-- End Suscribe Section -->



    <!-- ======= Contact Section ======= -->
    <?php include "contact.php"; ?>
   <!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php include "footer.php"; ?>
  <!-- End  Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <?php include "scripts.php"; ?>

</body>

</html>
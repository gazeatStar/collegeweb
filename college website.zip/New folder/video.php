<div class="video-container">
  <style>
       .video-container
        {
          display: flex;
          justify-content: space-between;
        }

        iframe
        {
          width: 650px; 
          height: 300px; 
        }
  </style>      

  <div class="video">
    <h3><b>College Blog</b></h3>
    <iframe width="685" height="315" src="https://www.youtube.com/embed/JGVMirq4BHQ?si=gnhjcL4ZPaHhgstW"frameborder="0" allowfullscreen></iframe>
  </div>

  <div class="video">
    <h3><b>Pongal Celebration</b></h3>
    <iframe width="685" height="315" src="https://www.youtube.com/embed/nGEbUZW8aZU"frameborder="0" allowfullscreen></iframe>
  </div>

  <style>
    h3 {
      color:purple;
      font-style:italic;
    }
  </style>
    
  </div>